=pod
Description: --- Put Description of Code Here ---
Created by: --- Put Name Here ---
Date: --- Put Date Here ---
=cut


# --- Please dont' edit anything in this section. Feel free to add Perl modules to use --- #
package Site::ng_inst_flows_2_min;

use warnings;
use strict;
use Date::Calc qw(Delta_Days Add_Delta_Days Today Now);
use misc qw(%monthToNum %txtToNum %frenchMon %alt_french_months GetBetween 
			getTables slurp clean parseDate parseDateMonText trim commaNumber get_gas_year 
			readFile formatDate getGasDate removeComma);
use log;
use base qw(Site);

sub key { "ng_inst_flows_2_min"; }
sub name { "ng_inst_flows_2_min";}
sub usesWWW { 1; }
#

#URL of website to scrape
my $URL = "http://energywatch.natgrid.co.uk/EDP-PublicUI/Public/InstantaneousFlowsIntoNTS.aspx";

sub scrape {
	
	#has the mechanize object. 
	my $self = shift;
		
=pod
#1)	INSTRUCTIONS:
1) Go to http://energywatch.natgrid.co.uk/EDP-PublicUI/Public/InstantaneousFlowsIntoNTS.aspx
2) Download the CSV at the bottom of the page. Please use this rather than the html download as it gives more info.
3) We'd like all the columns. You'll notice that half way down there is another heading; please ignore that.
4) Dates should be in yyyy-mm-dd. 

=cut
	my @data;
	
	$self->updateDB("eeg.enagas_monthly_arrivals",["eta","etd","vessel"],["berth"],\@data,name());
		
	#exits the method
	return 1;
	
}

1;



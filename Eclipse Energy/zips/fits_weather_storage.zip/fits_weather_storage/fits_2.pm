=pod
Description: --- Put Description of Code Here ---
Created by: --- Put Name Here ---
Date: --- Put Date Here ---
=cut


# --- Please dont' edit anything in this section. Feel free to add Perl modules to use --- #
package Site::fits_2;

use warnings;
use strict;
use Date::Calc qw(Delta_Days Add_Delta_Days Today Now);
use misc qw(%monthToNum %txtToNum %frenchMon %alt_french_months GetBetween 
			getTables slurp clean parseDate parseDateMonText trim commaNumber get_gas_year 
			readFile formatDate getGasDate removeComma);
use log;
use base qw(Site);

sub key { "fits_2"; }
sub name { "fits_2";}
sub usesWWW { 1; }
#

#URL of website to scrape
my $URL = "";

sub scrape {
	
	#has the mechanize object. 
	my $self = shift;
		
=pod
1) go to http://www.decc.gov.uk/en/content/cms/statistics/energy_stats/source/fits/fits.aspx
2) click on Monthly Central Feed-in Tariff Register Statistics
3) in the tab Month CFR - Confirmation Date, we want the data in the tab "Installed Capacity, by technology"	
4) we dont need the total. date should be in yyyy-mm-01 format. the final array should look like: <date,type,value>.


1) go to http://www.decc.gov.uk/en/content/cms/statistics/energy_stats/source/fits/fits.aspx
2) click on the link Weekly solar PV installation and capacity
3) in the tab Capacity installed_tariff, we want the data in the first table. dont worry about the total col.date in yyyy-mm-dd.
4) so the final array should look like: <date,tariff_band,value>

=cut
	my @data;
	
	$self->updateDB("eeg.fits_2_arrivals",["eta","etd","vessel"],["berth"],\@data,name());
		
	#exits the method
	return 1;
	
}

1;



=pod
Description: --- Put Description of Code Here ---
Created by: --- Put Name Here ---
Date: --- Put Date Here ---
=cut


# --- Please dont' edit anything in this section. Feel free to add Perl modules to use --- #
package Site::entsoe_consumption;

use warnings;
use strict;
use Date::Calc qw(Delta_Days Add_Delta_Days Today Now);
use misc qw(%monthToNum %txtToNum %frenchMon %alt_french_months GetBetween 
			getTables slurp clean parseDate parseDateMonText trim commaNumber get_gas_year 
			readFile formatDate getGasDate removeComma);
use log;
use base qw(Site);

sub key { "entsoe_consumption"; }
sub name { "entsoe_consumption";}
sub usesWWW { 1; }
#

#URL of website to scrape
my $URL = "https://www.entsoe.eu/db-query/consumption/mhlv-all-countries-for-a-specific-month/";

sub scrape {
	
	#has the mechanize object. 
	my $self = shift;
		
=pod
#1)	INSTRUCTIONS:
1) go to https://www.entsoe.eu/db-query/consumption/mhlv-all-countries-for-a-specific-month/
2) We want to download the last 3 months files each time in XLS format
3) We'd like the 2nd table in the file (the big one). The final array should look like: <date,hour,country,value>.


=cut
	my @data;
	
	$self->updateDB("eeg.enagas_monthly_arrivals",["eta","etd","vessel"],["berth"],\@data,name());
		
	#exits the method
	return 1;
	
}

1;


